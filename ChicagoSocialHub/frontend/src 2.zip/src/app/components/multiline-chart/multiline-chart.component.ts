import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import  'rxjs/Rx';
import { Station } from '../../station';
import { PlacesService } from '../../places.service';
import * as d3 from 'd3-selection';
import * as d3Scale from 'd3-scale';
import * as d3ScaleChromatic from 'd3-scale-chromatic';
import * as d3Shape from 'd3-shape';
import * as d3Array from 'd3-array';
import * as d3Axis from 'd3-axis';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { NgModule } from '@angular/core';
import { Place } from 'src/app/place';








@Component({
  selector: 'app-multiline-chart',
  templateUrl: './multiline-chart.component.html',
  styleUrls: ['./multiline-chart.component.css']
})
export class MultiLineChartComponent implements OnInit {

  stations: Station[]=[];
  title = 'Multi-Series Line Chart';

    

    svg: any;
    margin = {top: 20, right: 80, bottom: 30, left: 50};
    g: any;
  
    width: number;
    height: number;

    x;
    y;
    z;
    line;
    line2;
    data1;
  



  constructor(private placesService: PlacesService, private router: Router) { }

  ngOnInit() {
    
    this.fetchStations();
    

  }
  
  

  fetchStations() {
    this.placesService
      .getPlot_station()
      .subscribe((data: Station[]) => {
        this.stations = data;
        console.log(this.stations);

        var m=new Date();
        m.setHours(m.getHours()-7);
       
        data = data.filter(function(d) {
          return (d) => new Date(d.lastCommunicationTime) > m 
        })
        console.log(data);
        
        this.svg = d3.select('svg');

        this.width = this.svg.attr('width') - this.margin.left - this.margin.right;
        this.height = this.svg.attr('height') - this.margin.top - this.margin.bottom;

        this.g = this.svg.append('g').attr('transform', 'translate(' + this.margin.left + ',' + this.margin.top + ')');


        this.x = d3Scale.scaleTime().rangeRound([0, this.width]);
        this.y = d3Scale.scaleLinear().rangeRound([this.height, 0]);

        this.x.domain(d3Array.extent(this.stations, (d) => new Date(d.lastCommunicationTime.toString())));
        this.y.domain([0, d3Array.max(this.stations, (d) => d.totalDocks)]);

        // this.x = d3Scale.scaleTime().rangeRound([0, this.width]);
        // this.y = d3Scale.scaleLinear().rangeRound([this.height, 0]);
       
        // this.x.domain(d3Array.extent(this.stations, (d) => new Date(d.lastCommunicationTime.toString())));
        // this.y.domain([0, d3Array.max(this.stations, function(d){return d.availableDocks;})]);
        // //this.z = d3Scale.scaleOrdinal(d3ScaleChromatic.schemeCategory10);

        // this.line = d3Shape.line()
        //     .curve(d3Shape.curveBasis)
        //     .x( (d: any) => this.x(new Date(d.lastCommunicationTime.toString())))
        //     .y( (d: any) => this.y(d.availableDocks) );

        // this.x.domain(d3Array.extent(this.stations, (d) => d.lastCommunicationTime ));

        // this.y.domain([
        //     d3Array.min(this.stations, function(d) { return d.AvailableDocks;}),
        //     d3Array.max(this.stations, function(d) { return d.AvailableDocks;})
        // ]);

        //this.z.domain(this.stations.map(function(c) { return c.stationName; }));
        this.g.append('g')
        .attr('class', 'axis axis--x')
        .attr('transform', 'translate(0,' + this.height + ')')
        .call(d3Axis.axisBottom(this.x));

    this.g.append('g')
        .attr('class', 'axis axis--y')
        .call(d3Axis.axisLeft(this.y))
        .append('text')
        .attr('transform', 'rotate(-90)')
        .attr('y', 6)
        .attr('dy', '0.71em')
        .attr('fill', '#000')
        .text('AvailableDocks');

        this.line = d3Shape.line()
                    .x((d: any) => this.x(new Date(d.lastCommunicationTime.toString())))//d.loggingtime
                    .y((d: any) => this.y(d.availableDocks));
        // this.line2 = d3Shape.line()
        //           .x((d: any) => this.x( this.data1.toString()))//d.loggingtime
        //               .y((d: any) => this.y(d.availableDocks));
       
        this.g.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("class", "line")
         .attr("stroke", "green")
        .attr("stroke-width", 1.5)
         .attr("stroke-linejoin", "round")
         .attr("stroke-linecap", "round")
        .attr("d", this.line);

        this.g.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("class", "line2")
         .attr("stroke", "red")
        .attr("stroke-width", 1.5)
         .attr("stroke-linejoin", "round")
         .attr("stroke-linecap", "round")
        .attr("d", this.line2);
        //let station = this.g.selectAll('.station')
        //.data(this.stations)
    //     this.go
    // station.append('path')
    //     .attr('class', 'line')
    //     .attr('d', (d) => this.line(d) )
    //     .style('stroke', (d) => this.z(d.stationName) );
        
        // station.append('text')
        //     .datum(function(d) { return {lastCommunicationTime:d.lastCommunicationTime, availableDocks: d.availableDocks}; })
        //     .attr('transform', (d) => 'translate(' + this.x(d.lastCommunicationTime) + ',' + this.y(d.availableDocks) + ')' )
        //     .attr('x', 3)
        //     .attr('dy', '0.35em')
        //     .style('font', '10px sans-serif')
        //     .text(function(d) { return d.stationName; });
            
    
      });
  }


 








}



